#include <tar.h>

tar_error tar_open(tar* to, const char* filename, const char* mode) {
    to->fp = fopen(filename, mode);
    if (to->fp == NULL) {
        return ERRNO;
    }
}
