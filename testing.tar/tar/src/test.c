#include <stdio.h>

int main() {
    tar t;
    tar_open(&t, "temp.tar");
}
